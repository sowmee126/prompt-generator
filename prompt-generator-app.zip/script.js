const presets = {
  content: {
    task: "Create a 7-day content plan for a beginner fitness coach who wants to attract busy professionals.",
    audience: "Busy professionals who want simple fitness routines",
    role: "Senior content strategist",
    tone: "Friendly and conversational",
    format: "Table",
    context: "The coach offers 30-minute online sessions and wants practical posts for Instagram and LinkedIn.",
    constraints: "Avoid hype. Include hooks, post ideas, CTA lines, and one simple production tip per day."
  },
  business: {
    task: "Validate a digital product idea and create a simple launch plan.",
    audience: "Solo creators and freelancers",
    role: "Practical business strategist",
    tone: "Clear and practical",
    format: "Step-by-step plan",
    context: "The product is a Notion template that helps freelancers track leads, proposals, and follow-ups.",
    constraints: "Keep the plan realistic for one person. Include validation questions, pricing, and a 14-day launch sequence."
  },
  learning: {
    task: "Teach me the basics of personal finance using simple examples and practice questions.",
    audience: "College students with no finance background",
    role: "Patient tutor",
    tone: "Friendly and conversational",
    format: "Structured sections",
    context: "Focus on budgeting, saving, debt, investing basics, and financial habits.",
    constraints: "Use plain language. Include analogies, short quizzes, and common mistakes to avoid."
  },
  coding: {
    task: "Plan and build a small web app that turns rough notes into a polished task list.",
    audience: "Non-technical productivity users",
    role: "Senior product engineer",
    tone: "Direct and analytical",
    format: "Checklist",
    context: "The app should run in the browser, accept pasted notes, group related tasks, and let users export the list.",
    constraints: "Prioritize simple UX, accessible controls, local storage, and no account system."
  }
};

const fields = [
  "task",
  "audience",
  "role",
  "tone",
  "format",
  "context",
  "constraints",
  "askQuestions",
  "includeCritique"
];

const form = document.querySelector("#promptForm");
const output = document.querySelector("#output");
const qualityScore = document.querySelector("#qualityScore");
const wordCount = document.querySelector("#wordCount");
const detailCount = document.querySelector("#detailCount");
const savedCount = document.querySelector("#savedCount");
const savedList = document.querySelector("#savedList");
const statusLine = document.querySelector("#statusLine");

let savedPrompts = JSON.parse(localStorage.getItem("promptGeneratorSaved") || "[]");

function getValue(id) {
  const element = document.querySelector(`#${id}`);
  return element.type === "checkbox" ? element.checked : element.value.trim();
}

function setValue(id, value) {
  const element = document.querySelector(`#${id}`);
  if (element.type === "checkbox") {
    element.checked = Boolean(value);
    return;
  }
  element.value = value;
}

function buildPrompt() {
  const task = getValue("task") || "Describe the task clearly.";
  const audience = getValue("audience") || "the intended audience";
  const role = getValue("role") || "an expert assistant";
  const tone = getValue("tone");
  const format = getValue("format");
  const context = getValue("context") || "No extra context provided.";
  const constraints = getValue("constraints") || "Be accurate, specific, and useful.";
  const askQuestions = getValue("askQuestions");
  const includeCritique = getValue("includeCritique");

  const lines = [
    `Act as ${role}.`,
    "",
    `Task: ${task}`,
    "",
    `Audience: ${audience}`,
    `Tone: ${tone}`,
    `Output format: ${format}`,
    "",
    "Context:",
    context,
    "",
    "Requirements:",
    `- Follow these constraints: ${constraints}`,
    "- Make the answer specific, actionable, and easy to use.",
    "- Use examples where they make the output clearer.",
    "- Avoid generic advice unless it is tied to the task."
  ];

  if (askQuestions) {
    lines.push("- If essential information is missing, ask up to 3 clarifying questions before completing the task.");
  }

  if (includeCritique) {
    lines.push("- After drafting, review your own answer for gaps, vague claims, and practical next steps, then improve it once.");
  }

  lines.push("", "Final instruction:", "Deliver the best finished response, not a description of how you would approach it.");

  return lines.join("\n");
}

function updateStats() {
  const values = fields.map(getValue);
  const filled = values.filter(Boolean).length;
  const score = Math.round((filled / fields.length) * 100);
  const words = output.value.trim() ? output.value.trim().split(/\s+/).length : 0;
  const details = ["task", "audience", "role", "context", "constraints"].filter((id) => getValue(id).length > 12).length;

  qualityScore.textContent = `${score}%`;
  wordCount.textContent = words;
  detailCount.textContent = details;
  savedCount.textContent = savedPrompts.length;
}

function generatePrompt() {
  output.value = buildPrompt();
  showStatus("Prompt generated.");
  updateStats();
}

function showStatus(message) {
  statusLine.textContent = message;
  window.clearTimeout(showStatus.timer);
  showStatus.timer = window.setTimeout(() => {
    statusLine.textContent = "";
  }, 2400);
}

function applyPreset(name) {
  const preset = presets[name];
  Object.entries(preset).forEach(([id, value]) => setValue(id, value));
  document.querySelectorAll(".preset-card").forEach((button) => {
    button.classList.toggle("active", button.dataset.preset === name);
  });
  generatePrompt();
}

function renderSaved() {
  savedList.innerHTML = "";

  if (!savedPrompts.length) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "Saved prompts will appear here.";
    savedList.append(empty);
    updateStats();
    return;
  }

  savedPrompts.forEach((prompt, index) => {
    const item = document.createElement("article");
    item.className = "saved-item";

    const title = document.createElement("strong");
    title.textContent = `Prompt ${index + 1}`;

    const preview = document.createElement("p");
    preview.textContent = prompt;

    const loadButton = document.createElement("button");
    loadButton.type = "button";
    loadButton.textContent = "Load";
    loadButton.addEventListener("click", () => {
      output.value = prompt;
      updateStats();
      window.scrollTo({ top: 0, behavior: "smooth" });
    });

    item.append(title, preview, loadButton);
    savedList.append(item);
  });

  updateStats();
}

function savePrompt() {
  const prompt = output.value.trim();
  if (!prompt) return;

  savedPrompts = [prompt, ...savedPrompts.filter((item) => item !== prompt)].slice(0, 9);
  localStorage.setItem("promptGeneratorSaved", JSON.stringify(savedPrompts));
  showStatus("Prompt added to saved.");
  renderSaved();
}

function downloadPrompt() {
  const prompt = output.value.trim();
  if (!prompt) return;

  const blob = new Blob([prompt], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "generated-prompt.txt";
  link.click();
  URL.revokeObjectURL(url);
  showStatus("Prompt downloaded.");
}

async function sharePrompt() {
  const prompt = output.value.trim();
  if (!prompt) return;

  if (navigator.share) {
    try {
      await navigator.share({
        title: "Generated Prompt",
        text: prompt
      });
      showStatus("Share sheet opened.");
      return;
    } catch (error) {
      if (error.name === "AbortError") return;
    }
  }

  try {
    await navigator.clipboard.writeText(prompt);
    showStatus("Sharing is not available here, so the prompt was copied.");
  } catch (error) {
    showStatus("Sharing is not available here. Use Download instead.");
  }
}

document.querySelectorAll(".preset-card").forEach((button) => {
  button.addEventListener("click", () => applyPreset(button.dataset.preset));
});

document.querySelector("#generateBtn").addEventListener("click", generatePrompt);
document.querySelector("#randomizeBtn").addEventListener("click", () => {
  const keys = Object.keys(presets);
  applyPreset(keys[Math.floor(Math.random() * keys.length)]);
});
document.querySelector("#shareBtn").addEventListener("click", sharePrompt);
document.querySelector("#copyBtn").addEventListener("click", async () => {
  if (!output.value.trim()) return;
  try {
    await navigator.clipboard.writeText(output.value);
    showStatus("Prompt copied.");
  } catch (error) {
    showStatus("Copy was blocked by the browser. Use Download instead.");
  }
});
document.querySelector("#downloadBtn").addEventListener("click", downloadPrompt);
document.querySelector("#savePromptBtn").addEventListener("click", savePrompt);
document.querySelector("#clearBtn").addEventListener("click", () => {
  fields.forEach((id) => {
    if (document.querySelector(`#${id}`).type === "checkbox") return;
    setValue(id, "");
  });
  output.value = "";
  showStatus("Builder cleared.");
  updateStats();
});
document.querySelector("#clearSavedBtn").addEventListener("click", () => {
  savedPrompts = [];
  localStorage.removeItem("promptGeneratorSaved");
  showStatus("Saved prompts cleared.");
  renderSaved();
});

form.addEventListener("input", updateStats);
output.addEventListener("input", updateStats);

applyPreset("content");
renderSaved();
